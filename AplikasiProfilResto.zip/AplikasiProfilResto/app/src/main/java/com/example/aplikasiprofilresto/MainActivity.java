package com.example.aplikasiprofilresto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;

import com.example.aplikasiprofilresto.MainActivity;
import com.example.aplikasiprofilresto.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void pindah(View view) {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivities(intent);
    }

    private void startActivities(Intent intent) {
    }
}